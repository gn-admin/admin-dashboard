var CONFIG = {
  FIREBASE_PROJECT_ID: 'grupo-nebak',
  FIREBASE_API_KEY: 'AIzaSyChE9J08D71m9DMOBcJS012ZlbuLMcNGc8',
  ALLOWED_ORIGINS: ["https://gn-admin.github.io","http://localhost:8080","http://localhost:3000"],
  RATE_LIMIT: 100,
  REQUIRE_EMAIL_VERIFIED: false,
  ALLOW_ORIGIN_EMPTY: true,
  DRIVE_FOTOS_FOLDER_ID: '1Axr9kpXWuGlQtnMRmkl-lWhniESmBQoV',
  DRIVE_DOCS_FOLDER_ID: '1gZ1lNH2DJeCADkjShHRAEDbcWSpZ-0ke',
  DRIVE_FACTURAS_FOLDER_ID: '18u7tzcaPl2zBfwUE04WOziKl53ppciFM',
  CONTACT_EMAIL: '',
  ROLES: { ADMIN: 'admin', USER: 'usuario' },

  surveys: {
    'pre-adopcion-perros': {
      name: 'Encuesta Pre-Adopcion Perros',
      formId: '1FAIpQLSdBHgDpIBZNokAVnWCZKNd_wvgoKP1frjuxhi6D3wjFu46qlg',
      sheetId: '12aZ-QdvOtf8fujwPdGdeWl9WjVyQ_l0JPFp17_2nk60',
      sheetName: 'Respuestas de formulario 1',
      visible: true
    },
    'pre-adopcion-gatos': {
      name: 'Encuesta Pre-Adopcion Gatos',
      formId: '1FAIpQLScmQfRndm8POBr0b9I6jv6iyf87I2Lqz_hEtOm1ae2jHZxz3A',
      sheetId: '1K3HIx_UWZQRVg4stxLh7WYDLIMAgwTYqGchLtgDl5fc',
      sheetName: 'Respuestas de formulario 1',
      visible: true
    },
    'pre-acogida': {
      name: 'Solicitud de Acogida',
      formId: '1FAIpQLSfRFiKU5k0mMDCXTgPgwrv-xd5dap6yF0wIJ4f9qWxxtvVjKQ',
      sheetId: '1O59sMw8pF70AMHF5yOcDyyGYOPiaIbYhi5XW0aKftlc',
      sheetName: 'Respuestas de formulario 1',
      visible: true
    }
  },

  sheets: {
    animales: { sheetId: '1ff4cFu6wopYAlQjtqB7s7dPPgM-CGp7PgGB9CEMEgfw', sheetName: 'Animales' },
    familias: { sheetId: '1_60WlFtGqKmQUXAQK8Pm8soM4ZUWVopFNDc42Owx2Hg', sheetName: 'Familias' },
    adopciones: { sheetId: '1bcG7wA6iZq-y-I8wcAOy-Yv2niBozKPELhTqxSvwpk8', sheetName: 'Adopciones' },
    socios: { sheetId: '1XISjGJxfth9hBqYo5Kp4S8WC-BiQywP51qMIhHFmqoU', sheetName: 'Socios' },
    blacklist: { sheetId: '1BNdv7bjvRbU21TNDPMC1fefDk8erAZjrylx9ySDiK2Y', sheetName: 'Blacklist' },
    actividad: { sheetId: '1LfrDSentUybwF8UVDxg4Qd1XJMIz2rDa689hNi_Et7c', sheetName: 'Actividad' },
    candidaturas: { sheetId: '1YPfdC2Fu98fArZAdz_Xa0bvUWCDiVubwIp8Yuhd5EzY', sheetName: 'Candidaturas' },
    acogidas: { sheetId: '1o__u-R42X4u1S_M5yMzF3ZTjaJ7pQEqYAfdAP2rymbo', sheetName: 'Acogidas' },
    contratos: { sheetId: '1KnBD_BPZKdWJhbtJU1W1gJrk7zhPfpZg22awvPCDeys', sheetName: 'Contratos' },
    apadrinamientos: { sheetId: '1zN5znBCocWTzTmMdeDHMx-cc_aIi1PN1jQhTVmY61tg', sheetName: 'Apadrinamientos' },
    gastos: { sheetId: '162gB-YWctM9yQpaYrGzVe_qREoBZlSmLQodDXvb9WEM', sheetName: 'Gastos' },
    recordatorios: { sheetId: '1I5UBxTXmb6bWIz2J8DRVTKWe0D_WVtJ01lo24sD5P0Q', sheetName: 'Recordatorios' },
    donaciones: { sheetId: '1l-pM4OMtJKcd8Whsj32BuqJXnmwUzB9shwsxAUzwVdw', sheetName: 'Donaciones' },
    seguimientos: { sheetId: '1WDG0xJ69gWsALIT0vdhTbIOl86yGcSUe7bQuyl5R9ew', sheetName: 'Seguimientos' },
    documentos: { sheetId: '1W3n7cWOYOwQ5wOG0lyk3IfFaabyAluxlUhS7Ufcinbc', sheetName: 'Documentos' },
    inventario: { sheetId: '18sNQYXrYt1mlxXh7FxoMR1m1Iyi0pP_8TJ2Dv5QDkik', sheetName: 'Inventario' },
    grupos: { sheetId: '10uMc2RrR2QsK_mMmjC3Be2DsNnE9NTCLXDbbKM46EsE', sheetName: 'Grupos' },
    estados: { sheetId: '1o-lAsJBCDOu-ksbgjiwxM7dNDi42sUL9M8B4z1AZ_YE', sheetName: 'Estados' },
    notas: { sheetId: '1OeBXmoX2uRvZR6mj6ZjQe2D9SJdNq414A-zOKjhk4II', sheetName: 'Notas' }
  }
};
